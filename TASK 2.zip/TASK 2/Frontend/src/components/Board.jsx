import { useState, useEffect } from "react";
import Square from "./Square";
import axios from "axios";

function Board() {
  const [squares, setSquares] = useState(Array(9).fill(null));
  const [xIsNext, setXIsNext] = useState(true);
  
  const [difficulty, setDifficulty] = useState(null);
  const [gameStarted, setGameStarted] = useState(false);

// difficulty handler
  function handleStartGame(level) {
    setDifficulty(level);
    setGameStarted(true);
  }

  function handleClick(i) {
    if (squares[i] || calculateWinner(squares)) {
      return;
    }
    const nextSquares = squares.slice();
    if (xIsNext) {
      nextSquares[i] = "X";
    } else {
      nextSquares[i] = "O";
    }
    setSquares(nextSquares);
    setXIsNext(!xIsNext);
  }


  function handlePlayAgain() {
    setSquares(Array(9).fill(null));
    setXIsNext(true);
    setGameStarted(false); //back to start screen
    setDifficulty(null);
  }

  useEffect(() => {
    if (gameStarted && !xIsNext && !calculateWinner(squares)) {
      
      const getAiMove = async () => {
        try {
          const response = await axios.post('http://127.0.0.1:5000/api/get_move', {
            board: squares,
            difficulty: difficulty //chosen difficulty
          });
          
          const aiMove = response.data.move;
          if (aiMove !== null) {
            handleClick(aiMove);
          }
        } catch (error) {
          console.error("Error fetching AI move:", error);
        }
      };
      
      // delay
      setTimeout(getAiMove, 500);
    }
  }, [squares, xIsNext, gameStarted, difficulty]); // Added new dependencies


  const winner = calculateWinner(squares);
  const isDraw = !winner && squares.every(square => square !== null);
  let status;
  if (winner) {
    status = "Winner: " + winner;
  } else if (isDraw) {
    status = "It's a draw!";
  } else {
    status = "Next player: " + (xIsNext ? "X" : "O");
  }

  //difficulty selection
  if (!gameStarted) {
    return (
      <div className="start-screen">
        <h1>Welcome to Tic-Tac-Toe</h1>
        <h2>Select Difficulty:</h2>
        <button className="difficulty-btn" onClick={() => handleStartGame('easy')}>
          Easy
        </button>
        <button className="difficulty-btn" onClick={() => handleStartGame('hard')}>
          Hard (Unbeatable)
        </button>
      </div>
    );
  }


  return (
    <>
      <div className="status">{status}</div>
      <div className="board-row">
        <Square value={squares[0]} onSquareClick={() => handleClick(0)} />
        <Square value={squares[1]} onSquareClick={() => handleClick(1)} />
        <Square value={squares[2]} onSquareClick={() => handleClick(2)} />
      </div>
      <div className="board-row">
        <Square value={squares[3]} onSquareClick={() => handleClick(3)} />
        <Square value={squares[4]} onSquareClick={() => handleClick(4)} />
        <Square value={squares[5]} onSquareClick={() => handleClick(5)} />
      </div>
      <div className="board-row">
        <Square value={squares[6]} onSquareClick={() => handleClick(6)} />
        <Square value={squares[7]} onSquareClick={() => handleClick(7)} />
        <Square value={squares[8]} onSquareClick={() => handleClick(8)} />
      </div>

      {(winner || isDraw) && (
        <button className="play-again" onClick={handlePlayAgain}>
          Play Again
        </button>
      )}
    </>
  );
}

//get winner
function calculateWinner(squares) {
  const lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6],
    [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]
  ];
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
  }
  return null;
}

export default Board;