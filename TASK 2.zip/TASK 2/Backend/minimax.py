import random

PLAYER_X = 'X'
PLAYER_O = 'O'
EMPTY = None


def check_winner(board):
    lines = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
        [0, 4, 8], [2, 4, 6]              # Diagonals
    ]
    for line in lines:
        a, b, c = line
        if board[a] and board[a] == board[b] and board[a] == board[c]:
            return board[a]
    if EMPTY not in board:
        return 'DRAW'
    return None


#minimax
def minimax(board, is_maximizing, alpha, beta):
    winner = check_winner(board)
    if winner:
        if winner == PLAYER_O:
            return 1
        elif winner == PLAYER_X:
            return -1
        else:
            return 0

    if is_maximizing:
        best_score = -float('inf')
        for i in range(9):
            if board[i] == EMPTY:
                board[i] = PLAYER_O
                score = minimax(board, False, alpha, beta)
                board[i] = EMPTY
                best_score = max(score, best_score)
                alpha = max(alpha, best_score)
                if beta <= alpha: break
        return best_score
    else:
        best_score = float('inf')
        for i in range(9):
            if board[i] == EMPTY:
                board[i] = PLAYER_X
                score = minimax(board, True, alpha, beta)
                board[i] = EMPTY
                best_score = min(score, best_score)
                beta = min(beta, best_score)
                if beta <= alpha: break
        return best_score


#find best move
def find_best_move(board):
    best_move = -1
    best_score = -float('inf')
    for i in range(9):
        if board[i] == EMPTY:
            board[i] = PLAYER_O
            score = minimax(board, False, -float('inf'), float('inf'))
            board[i] = EMPTY
            if score > best_score:
                best_score = score
                best_move = i
    return best_move


# --- 👇 2. ADD THIS NEW FUNCTION ---
def find_random_move(board):
    #random available move
    available_moves = []
    for i, spot in enumerate(board):
        if spot == EMPTY:
            available_moves.append(i)

    if available_moves:
        return random.choice(available_moves)

    return -1