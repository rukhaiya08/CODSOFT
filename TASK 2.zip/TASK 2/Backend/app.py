from flask import Flask, request, jsonify
from flask_cors import CORS
from minimax import find_best_move, find_random_move

app = Flask(__name__)
CORS(app)

@app.route('/api/get_move', methods=['POST'])
def get_move():
    data = request.json
    board = data.get('board')
    #choosing mode
    difficulty = data.get('difficulty', 'hard')

    if difficulty == 'easy':
        ai_move_index = find_random_move(board)
    else:
        ai_move_index = find_best_move(board)

    return jsonify({ 'move': ai_move_index })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)