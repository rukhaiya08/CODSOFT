import json
import random
from difflib import SequenceMatcher

def load_intents(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict) and "intents" in data:
        return data["intents"]
    return data

def match_intent(user_input, intents, threshold=0.8):
    user_input = user_input.lower().strip()
    for intent in intents:
        for pattern in intent["patterns"]:
            pattern_clean = pattern.lower().strip()
            score = SequenceMatcher(None, user_input, pattern_clean).ratio()
            if score >= threshold or user_input == pattern_clean:
                return random.choice(intent["responses"])
    return "Sorry, I don't understand."

# Usage
intents = load_intents("data/chat/intents.json")

def handle(user_input):
    return match_intent(user_input, intents)
