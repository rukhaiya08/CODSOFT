import random

# Initialize a new blank board
def new_board():
    return [' '] * 9

def render_board_html(board):
    html = '<div class="ttt-board">'
    for i in range(3):
        html += '<div class="ttt-row">'
        for j in range(3):
            idx = 3 * i + j
            symbol = board[idx]
            cell_class = "ttt-cell"
            # Optionally add a class for X or O
            if symbol == 'X':
                cell_class += " ttt-x"
            elif symbol == 'O':
                cell_class += " ttt-o"
            html += f'<div class="{cell_class}" data-idx="{idx}">{symbol if symbol != " " else "&nbsp;"}</div>'
        html += '</div>'
    html += '</div>'
    return html


# Check win/tie
def check_winner(board, player):
    wins = [
        [0,1,2], [3,4,5], [6,7,8],
        [0,3,6], [1,4,7], [2,5,8],
        [0,4,8], [2,4,6]
    ]
    for line in wins:
        if all(board[i] == player for i in line):
            return True
    return False

def is_full(board):
    return all(space != ' ' for space in board)

# Make bot move (simple: random empty)
def bot_move(board):
    empties = [i for i, val in enumerate(board) if val == ' ']
    if empties:
        pos = random.choice(empties)
        board[pos] = 'O'
    return board

# Parse user move (1-9)
def parse_move(move_str, board):
    try:
        pos = int(move_str)
        # Prefer user-input (1-9) mapping
        if 1 <= pos <= 9 and board[pos - 1] == ' ':
            return pos - 1
        elif 0 <= pos <= 8 and board[pos] == ' ':
            return pos
    except Exception:
        pass
    return None





def handle(game_state=None, user_move=None):
    if not game_state:
        board = new_board()
        message = "Welcome to Tic-Tac-Toe! You are X. Enter your move (1-9):<br>" + render_board_html(board)
        return {"message": message, "state": {"board": board, "turn": "X"}}

    board = game_state["board"]
    turn = game_state["turn"]

    print("Board before user move:", board)
    if user_move and turn == 'X':
        pos = parse_move(user_move, board)
        if pos is not None:
            board[pos] = 'X'
            print("Board after user X move:", board)
            if check_winner(board, 'X'):
                return {"message": render_board_html(board) + "<br>You win! 🎉", "state": None}
            elif is_full(board):
                return {"message": render_board_html(board) + "<br>It's a tie!", "state": None}
            turn = 'O'
        else:
            return {"message": "Invalid move. Enter a number (1-9) for an empty space.<br>" + render_board_html(board),
                    "state": {"board": board, "turn": "X"}}

    if turn == 'O':
        bot_move(board)
        print("Board after bot O move:", board)
        if check_winner(board, 'O'):
            return {"message": render_board_html(board) + "<br>Bot wins!", "state": None}
        elif is_full(board):
            return {"message": render_board_html(board) + "<br>It's a tie!", "state": None}
        turn = 'X'

    message = "Your move (1-9):<br>" + render_board_html(board)
    return {"message": message, "state": {"board": board, "turn": turn}}

