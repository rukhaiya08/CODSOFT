import random
from utils import load_json

# load the data once
flirt_data = load_json("data/flirt/pickup.json")

def handle(category='clean'):
    filtered = [
        item["text"] for item in flirt_data
        if item.get("category", "clean") == category and set(item["text"].strip()) != {"*"}
    ]
    if not filtered:
        return f"Sorry, I don't have any {category} flirt responses yet."
    return random.choice(filtered)
