import random
from utils import load_json
import glob
import os

# Load all jokes files and combine them
jokes_data = []
jokes_dir = "data/jokes"
joke_files = glob.glob(os.path.join(jokes_dir, "*.json"))
loaded_files = 0

for filepath in joke_files:
    try:
        file_data = load_json(filepath)
        if isinstance(file_data, list):
            jokes_data.extend(file_data)
            loaded_files += 1
    except Exception as e:
        print(f"Error loading {filepath}: {e}")

# Count joke types
qa_count = len([j for j in jokes_data if isinstance(j, dict) and j.get("type") == "qa"])
oneliner_count = len([j for j in jokes_data if isinstance(j, dict) and j.get("type") == "oneliner"])

print(f"--- Loaded {loaded_files} joke files. Total jokes: {len(jokes_data)} ---")
print(f"- Q/A jokes: {qa_count}")
print(f"- One-liner jokes: {oneliner_count}")


def handle(category='clean'):
    filtered = [j for j in jokes_data if j.get('category', 'clean') == category]
    if not filtered:
        return "Sorry, I don't have any jokes in that category."
    joke_entry = random.choice(filtered)

    # If Q/A joke, return as a tuple (setup, punchline)
    if isinstance(joke_entry, dict) and joke_entry.get("type") == "qa":
        return joke_entry["setup"], joke_entry["punchline"]
    # If one-liner joke, return the string directly
    elif isinstance(joke_entry, dict) and joke_entry.get("type") == "oneliner":
        return joke_entry["joke"]
    elif isinstance(joke_entry, dict) and "joke" in joke_entry:
        return joke_entry["joke"]
    elif isinstance(joke_entry, str):
        return joke_entry
    else:
        return "Sorry, I couldn't find a joke."

