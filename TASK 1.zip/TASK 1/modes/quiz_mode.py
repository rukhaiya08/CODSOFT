# modes/quiz_mode.py
import random
import os
from utils import load_json

# The path where all your new quiz files are stored.
QUIZ_FOLDER_PATH = "data/quiz"


def get_available_categories():
    #scans the whole folder
    if not os.path.exists(QUIZ_FOLDER_PATH):
        return []

    categories = []
    for filename in os.listdir(QUIZ_FOLDER_PATH):
        if filename.startswith("quiz_") and filename.endswith(".json"):
            #extract the category name
            category_part = filename.replace("quiz_", "").replace(".json", "")

            #user friendly format conversion
            friendly_name = category_part.replace("_", " ").title()
            friendly_name = friendly_name.replace(" And ", " & ").replace("Science Computers", "Science: Computers")

            categories.append(friendly_name)

    return sorted(categories)


def start_quiz(category=None):

    available_categories = get_available_categories()
    if not available_categories:
        return None  #no quiz files found

    chosen_category = category
    if not chosen_category:
        #random category
        chosen_category = random.choice(available_categories)

    #friendly to file name
    clean_name = chosen_category.lower().replace(" & ", "_and_").replace(": ", "_").replace(" ", "_")
    filename = f"quiz_{clean_name}.json"
    file_path = os.path.join(QUIZ_FOLDER_PATH, filename)

    # Load the data from the chosen file
    quiz_data = load_json(file_path)

    if quiz_data:
        return random.choice(quiz_data)

    return None  # Return None if the file was empty or couldn't be loaded