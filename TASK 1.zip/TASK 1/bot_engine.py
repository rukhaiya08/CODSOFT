# bot_engine.py
from modes import chat_mode, jokes_mode, flirt_mode, quiz_mode, game_mode

# --- Global State & Data ---
bot_state = {
    "score": 0,
    "current_quiz_question": None,
    "current_quiz_category": None,
    "awaiting_question_count": False,
    "awaiting_continue": False,
    "awaiting_category_choice": False,
    "quiz_question_total": 0,
    "quiz_question_count": 0,
    # For jokes
    "awaiting_joke_answer": False,
    "current_joke_punchline": None,
    "joke_session": False,
    "current_joke_category": 'clean',
    # For games
    "current_game_state": None,  # Store tic-tac-toe board/turn state
    "in_game": False
}



mode_handlers = {
    "chat": chat_mode.handle,
    "jokes": jokes_mode.handle,
    "flirt": flirt_mode.handle,
    "game": game_mode.handle
}





AVAILABLE_QUIZ_CATEGORIES = []


def load_categories():
    global AVAILABLE_QUIZ_CATEGORIES
    AVAILABLE_QUIZ_CATEGORIES = quiz_mode.get_available_categories()
    print(f"--- Bot is ready. Loaded {len(AVAILABLE_QUIZ_CATEGORIES)} quiz categories. ---")


def get_bot_response(user_input):
    user_input = user_input.lower()
    chosen_category = next((cat for cat in AVAILABLE_QUIZ_CATEGORIES if cat.lower() == user_input), None)

    # 1. If user is awaiting a joke punchline
    if bot_state.get("awaiting_joke_answer"):
        punchline = bot_state.get("current_joke_punchline", "Here's the answer!")
        bot_state["awaiting_joke_answer"] = False
        bot_state["current_joke_punchline"] = None
        if bot_state.get("joke_session"):
            return {"type": "text", "content": f"{punchline}\n\nWant another joke? (yes/no)"}
        return {"type": "text", "content": punchline}

    # 2. If user is in joke session, handle yes/no for more
    if bot_state.get("joke_session"):
        if "yes" in user_input:
            joke = mode_handlers["jokes"](bot_state.get("current_joke_category", 'clean'))  # Use the session's category
            if isinstance(joke, tuple) and len(joke) == 2:
                setup, punchline = joke
                bot_state["awaiting_joke_answer"] = True
                bot_state["current_joke_punchline"] = punchline
                return {"type": "text", "content": setup}
            return {"type": "text", "content": joke}
        elif "no" in user_input:
            bot_state["joke_session"] = False
            bot_state["current_joke_category"] = 'clean'  # Reset to default
            return {"type": "text", "content": "Glad you enjoyed the jokes! Let me know what else you’d like to do."}

    # 3. If joke session should be started by trigger phrases
    if "tell me jokes" in user_input or "keep telling jokes" in user_input or "joke session" in user_input:
        bot_state["joke_session"] = True
        joke_category = 'dark' if "dark joke" in user_input or "offensive joke" in user_input or "edgy joke" in user_input else 'clean'
        bot_state["current_joke_category"] = joke_category  # <-- Store for session
        joke = mode_handlers["jokes"](joke_category)
        if isinstance(joke, tuple) and len(joke) == 2:
            setup, punchline = joke
            bot_state["awaiting_joke_answer"] = True
            bot_state["current_joke_punchline"] = punchline
            return {"type": "text", "content": setup}
        return {"type": "text", "content": joke}

    if "joke" in user_input:
        joke_category = 'dark' if "dark joke" in user_input or "offensive joke" in user_input or "edgy joke" in user_input else 'clean'
        joke = mode_handlers["jokes"](joke_category)
        print("Selected joke:", joke)
        if isinstance(joke, tuple) and len(joke) == 2:
            setup, punchline = joke
            bot_state["awaiting_joke_answer"] = True
            bot_state["current_joke_punchline"] = punchline
            return {"type": "text", "content": setup}
        return {"type": "text", "content": joke}

    # --- State 1: Awaiting 'yes'/'no' to continue ---
    if bot_state["awaiting_continue"]:
        if "yes" in user_input:
            bot_state.update({"awaiting_continue": False, "awaiting_question_count": True})
            return {"type": "text", "content": "Great! How many more questions would you like?"}
        elif "no" in user_input:
            bot_state.update({"awaiting_continue": False, "current_quiz_category": None, "score": 0})
            return {"type": "text", "content": "OK, thanks for playing! Let me know what you want to do next."}
        else:
            return {"type": "text", "content": "Please answer with 'yes' or 'no'."}

    # --- State 2: Awaiting number of questions ---
    if bot_state["awaiting_question_count"]:
        try:
            num_questions = int(user_input)
            if num_questions > 0:
                bot_state.update(
                    {"quiz_question_total": num_questions, "quiz_question_count": 0, "awaiting_question_count": False})
                question_data = quiz_mode.start_quiz(category=bot_state["current_quiz_category"])
                bot_state["current_quiz_question"] = question_data

                # **THE FIX**: Return a LIST of messages to be sent sequentially.
                return [
                    {"type": "text", "content": f"OK, {num_questions} questions it is! Let's start."},
                    {
                        "type": "quiz",
                        "question_meta": f"Question (1/{num_questions})",
                        "question_text": question_data['question'],
                        "options": question_data['options']
                    }
                ]
            else:
                return {"type": "text", "content": "Please enter a positive number."}
        except (ValueError, TypeError):
            return {"type": "text",
                    "content": "That doesn't look like a valid number. Please enter how many questions you'd like."}

    # --- State 3: Awaiting an answer to a question ---
    if bot_state["current_quiz_question"]:
        is_correct = user_input == bot_state["current_quiz_question"]['answer'].lower()
        if is_correct:
            bot_state["score"] += 1
            feedback = f"Correct! Your score is {bot_state['score']}."
        else:
            correct_answer = bot_state["current_quiz_question"]['answer']
            feedback = f"Sorry, the correct answer was '{correct_answer}'. Your score is {bot_state['score']}."

        bot_state["quiz_question_count"] += 1
        if bot_state["quiz_question_count"] >= bot_state["quiz_question_total"]:
            bot_state.update({"awaiting_continue": True, "current_quiz_question": None})
            return {"type": "text",
                    "content": f"{feedback}\n\nThat's all the questions! Would you like to play another round? (yes/no)"}
        else:
            next_question = quiz_mode.start_quiz(category=bot_state["current_quiz_category"])
            bot_state["current_quiz_question"] = next_question
            q_num, total = bot_state['quiz_question_count'] + 1, bot_state['quiz_question_total']

            # **THE FIX**: Also return a LIST of messages here for the next question.
            return [
                {
                    "type": "feedback",  # A new type to isolate feedback styling if needed
                    "content": feedback,
                    "is_correct": is_correct
                },
                {
                    "type": "quiz",
                    "question_meta": f"Next question ({q_num}/{total})",
                    "question_text": next_question['question'],
                    "options": next_question['options']
                }
            ]
    # --- Game State Handling ---
    # --- Game State Handling ---
    if bot_state.get("in_game") and bot_state.get("current_game_state"):
        # User is in a game, process their move
        game_result = mode_handlers["game"](bot_state["current_game_state"], user_input)

        if game_result["state"] is None:
            # Game ended
            bot_state["in_game"] = False
            bot_state["current_game_state"] = None
        else:
            # Game continues
            bot_state["current_game_state"] = game_result["state"]

        return {"type": "text", "content": game_result["message"]}

    # --- State 4: Normal Chat and Intent Detection ---
    if bot_state["awaiting_category_choice"] and chosen_category:
        bot_state.update({"current_quiz_category": chosen_category, "awaiting_category_choice": False,
                          "awaiting_question_count": True})
        return {"type": "text", "content": f"You chose {chosen_category}! How many questions would you like to answer?"}

    if "game" in user_input or "tic tac toe" in user_input or "play" in user_input:
        # Start a new game
        game_result = mode_handlers["game"]()
        bot_state["in_game"] = True
        bot_state["current_game_state"] = game_result["state"]
        return {"type": "text", "content": game_result["message"]}

    if "quiz" in user_input:
        bot_state["awaiting_category_choice"] = True
        return {"type": "category_selection", "content": "I have quizzes on these topics. Which one would you like?",
                "options": AVAILABLE_QUIZ_CATEGORIES}


    if bot_state["awaiting_category_choice"]:
        return {"type": "text", "content": "Please choose a category from the options above to start a quiz."}

    # Default: chat mode
    # Default: chat mode
    return {"type": "text", "content": mode_handlers["chat"](user_input)}


load_categories()

