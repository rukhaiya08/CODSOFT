document.addEventListener('DOMContentLoaded', () => {
    const chatForm = document.getElementById('chat-form');
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');

    let awaitingName = true;

    // Helper functions to store/retrieve name
    function setUserName(name) {
        sessionStorage.setItem('userName', name);
    }
    function getUserName() {
        return sessionStorage.getItem('userName') || '';
    }
    function setBotName(name) {
        sessionStorage.setItem('botName', name);
    }
    function getBotName() {
        return sessionStorage.getItem('botName') || 'Smart Chatbot';
    }

    // Initial greeting/request for user name
    setTimeout(() => {
        addMessage({ type: 'text', content: "Hi, this is Smart Chatbot. How should I address you?" }, 'bot');
        awaitingName = true;
    }, 500);

    function addMessage(messageData, sender) {
        const oldOptions = document.querySelector('.options-container');
        if (oldOptions) oldOptions.remove();

        const messageDiv = document.createElement('div');
        messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');

        if (messageData.type === 'quiz') {
            const wrapper = document.createElement('div');
            wrapper.classList.add('quiz-content-wrapper');
            if (messageData.question_meta) {
                const metaP = document.createElement('p');
                metaP.className = 'quiz-meta';
                metaP.textContent = messageData.question_meta;
                wrapper.appendChild(metaP);
            }
            if (messageData.question_text) {
                const questionP = document.createElement('p');
                questionP.className = 'quiz-question';
                questionP.textContent = `Q: ${messageData.question_text}`;
                wrapper.appendChild(questionP);
            }
            messageDiv.appendChild(wrapper);
        } else if (messageData.type === 'feedback') {
            const feedbackP = document.createElement('p');
            feedbackP.className = 'quiz-feedback';
            if (messageData.is_correct === true) feedbackP.classList.add('correct');
            if (messageData.is_correct === false) feedbackP.classList.add('incorrect');
            feedbackP.innerHTML = messageData.content.replace(/\n/g, '<br>');
            messageDiv.appendChild(feedbackP);
        } else {
            const content = messageData.content || '';
            messageDiv.innerHTML = content.replace(/\n/g, '<br>');
        }

        chatBox.appendChild(messageDiv);

        // --- Quiz/category options handling ---
        if ((messageData.type === 'quiz' || messageData.type === 'category_selection') && messageData.options) {
            const optionsContainer = document.createElement('div');
            optionsContainer.classList.add('options-container');
            messageData.options.forEach(option => {
                const button = document.createElement('button');
                button.classList.add('option-button');
                button.textContent = option;
                button.addEventListener('click', () => handleOptionClick(option));
                optionsContainer.appendChild(button);
            });
            chatBox.appendChild(optionsContainer);
        }

        // --- Attach Tic-Tac-Toe grid click handlers ---
        if (messageData.content && messageData.content.includes('ttt-board')) {
            setTimeout(setupTicTacToeClicks, 75);
        }

        scrollToBottom();
    }

    function setupTicTacToeClicks() {
        // Get all boards, use the last one (most recent)
        const boards = chatBox.querySelectorAll('.ttt-board');
        if (!boards.length) return;
        const board = boards[boards.length - 1];
        board.querySelectorAll('.ttt-cell').forEach(cell => {
            cell.style.pointerEvents = "auto";
            if ((cell.textContent.trim() === "" || cell.innerHTML === "&nbsp;")) {
                cell.style.cursor = "pointer";
                cell.onclick = function handler() {
                    const idx = cell.getAttribute('data-idx');
                    addMessage({ type: 'text', content: `${parseInt(idx) + 1}` }, 'user');
                    sendMessageToServer(`${parseInt(idx) + 1}`);
                    cell.onclick = null;
                };
            } else {
                cell.style.cursor = "default";
                cell.onclick = null;
            }
        });
    }


    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.classList.add('bot-message', 'typing-indicator');
        typingDiv.innerHTML = '<span></span><span></span><span></span>';
        chatBox.appendChild(typingDiv);
        scrollToBottom();
        return typingDiv;
    }

    function scrollToBottom() {
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    async function sendMessageToServer(messageText) {
        const typingIndicator = showTypingIndicator();
        try {
            const response = await fetch('/message', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: messageText }),
            });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            const rawData = await response.json();
            const data = rawData.response;

            chatBox.removeChild(typingIndicator);

            // --- Handle both single and multiple message responses ---
            if (Array.isArray(data)) {
                data.forEach((message, index) => {
                    setTimeout(() => {
                        addMessage(message, 'bot');
                    }, (index + 1) * 600);
                });
            } else {
                setTimeout(() => {
                    addMessage(data, 'bot');
                }, 500);
            }

        } catch (error) {
            console.error('Error connecting to the bot:', error);
            if (typingIndicator.parentNode) {
                chatBox.removeChild(typingIndicator);
            }
            addMessage({ type: 'text', content: 'Oops! I seem to be having trouble connecting.' }, 'bot');
        }
    }

    function handleOptionClick(optionText) {
        addMessage({ type: 'text', content: optionText }, 'user');
        sendMessageToServer(optionText);
    }

    chatForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const messageText = userInput.value.trim();
        if (messageText === '') return;

        addMessage({ type: 'text', content: messageText }, 'user');
        userInput.value = '';

        // -- Step: Handle expected name input --
        if (awaitingName) {
            setUserName(messageText);
            awaitingName = false;
            setTimeout(() => {
                addMessage({
                    type: 'text',
                    content: `Hello ${messageText}! I'm ${getBotName()}. You can ask me for a joke, or we can play a quiz.`
                }, 'bot');
            }, 500);
            return;
        }

        // -- Step: Handle bot renaming (user input like "change your name to ___") --
        const renameMatch = messageText.match(/change (your )?name to ([\w\s]+)/i);
        if (renameMatch) {
            const newBotName = renameMatch[2];
            setBotName(newBotName);
            setTimeout(() => {
                addMessage({
                    type: 'text',
                    content: `Okay, you can call me ${newBotName} from now on!`
                }, 'bot');
            }, 500);
            return;
        }

        // -- Otherwise, send to server --
        sendMessageToServer(messageText);
    });
});

// === Separate Info Icon Modal code, as a new top-level block! ===
document.addEventListener('DOMContentLoaded', function() {
    const infoIcon = document.getElementById('info-icon');
    const infoModal = document.getElementById('info-modal');
    const closeModal = document.getElementById('close-modal');
    if (infoIcon && infoModal && closeModal) {
        infoIcon.onclick = function() { infoModal.style.display = 'block'; };
        closeModal.onclick = function() { infoModal.style.display = 'none'; };
        window.addEventListener('click', function(e) {
            if (
                infoModal.style.display === 'block'
                && !infoModal.contains(e.target)
                && e.target !== infoIcon
            ) {
                infoModal.style.display = 'none';
            }
        });
    }
});
