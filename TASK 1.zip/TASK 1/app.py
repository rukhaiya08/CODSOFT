# app.py
from flask import Flask, render_template, request, jsonify
from bot_engine import get_bot_response  # Import your new bot logic function

app = Flask(__name__)


# This route serves the main HTML page
@app.route("/")
def home():
    return render_template("index.html")


# This is the API endpoint that the JavaScript will call
@app.route("/message", methods=["POST"])
def message():
    user_input = request.json.get("message")
    if not user_input:
        return jsonify({"error": "No message provided"}), 400

    bot_reply = get_bot_response(user_input)
    return jsonify({"response": bot_reply})


if __name__ == "__main__":
    app.run(debug=True)