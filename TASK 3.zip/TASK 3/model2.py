import string
import pickle
import numpy as np
import tensorflow as tf
import os
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.utils import to_categorical, plot_model
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, LSTM, Embedding, Dropout, add
from tensorflow.keras.callbacks import ModelCheckpoint

# File Paths
CAPTION_FILE = 'captions.txt'
TOKENIZER_FILE = 'tokenizer.pkl'
FEATURES_FILE = 'features.pkl'
MODEL_WEIGHTS_FILE = 'model_weights.h5'

# Text loading function
def load_captions(filename):
    with open(filename, 'r') as file:
        doc = file.read()
    captions_map = {}
    for line in doc.split('\n')[1:]:  # Skip header
        parts = line.split(',', 1)
        if len(parts) < 2:
            continue
        image_id, caption = parts[0], parts[1]
        if image_id not in captions_map:
            captions_map[image_id] = []
        captions_map[image_id].append(caption)
    return captions_map

# Cleans the captions
def clean_captions(captions_map):
    table = str.maketrans('', '', string.punctuation)
    for image_id, caption_list in captions_map.items():
        cleaned_list = []
        for caption in caption_list:
            caption = caption.split()
            caption = [word.lower() for word in caption]
            caption = [word.translate(table) for word in caption]
            caption = [word for word in caption if len(word) > 1]
            caption = [word for word in caption if word.isalpha()]
            cleaned_caption = '<start> ' + ' '.join(caption) + ' <end>'
            cleaned_list.append(cleaned_caption)
        captions_map[image_id] = cleaned_list
    return captions_map


# Gets the max length of the captions
def get_max_length(captions_dict):
    all_captions = []
    for key in captions_dict:
        all_captions.extend(captions_dict[key])
    return max(len(d.split()) for d in all_captions)


# Generates the data
def create_sequences(captions_list, image_features):
    X1, X2, y = [], [], []

    for caption in captions_list:
        seq = tokenizer.texts_to_sequences([caption])[0]
        for i in range(1, len(seq)):
            in_seq, out_seq = seq[:i], seq[i]
            # Pad the input sequence to be max_length
            in_seq = pad_sequences([in_seq], maxlen=max_length, padding='post')[0]
            out_seq = to_categorical([out_seq], num_classes=vocab_size)[0]
            X1.append(np.squeeze(image_features))
            X2.append(in_seq)
            y.append(out_seq)

    return np.array(X1), np.array(X2), np.array(y)


def data_generator(batch_size):
    while 1:
        image_ids = list(captions_map.keys())
        np.random.shuffle(image_ids)

        for i in range(0, len(image_ids), batch_size):
            current_batch = image_ids[i: i + batch_size]
            batch_X1, batch_X2, batch_y = [], [], []

            for image_id_jpg in current_batch:
                image_id = image_id_jpg.split('.')[0]
                if image_id not in image_features:
                    continue
                img_feats = image_features[image_id]
                caps = captions_map[image_id_jpg]
                X1, X2, y = create_sequences(caps, img_feats)

                batch_X1.extend(X1)
                batch_X2.extend(X2)
                batch_y.extend(y)

            # Yield a tuple of inputs
            yield (np.array(batch_X1), np.array(batch_X2)), np.array(batch_y)


# Decoder model
def define_model():
    inputs1 = Input(shape=(1000,))
    fe1 = Dropout(0.5)(inputs1)
    fe2 = Dense(256, activation='relu')(fe1)

    # Input 2: Text sequence
    inputs2 = Input(shape=(max_length,))
    se1 = Embedding(vocab_size, 256, mask_zero=True)(inputs2)
    se2 = Dropout(0.5)(se1)
    se3 = LSTM(256)(se2)

    # Merge
    decoder1 = add([fe2, se3])
    decoder2 = Dense(256, activation='relu')(decoder1)
    outputs = Dense(vocab_size, activation='softmax')(decoder2)

    model = Model(inputs=[inputs1, inputs2], outputs=outputs)
    model.compile(loss='categorical_crossentropy', optimizer='adam')

    print(model.summary())
    return model



# Load and clean captions
print("Loading and cleaning captions...")
captions_map = load_captions(CAPTION_FILE)
captions_map = clean_captions(captions_map)

# Load the tokenizer
print("Loading tokenizer...")
with open(TOKENIZER_FILE, 'rb') as f:
    tokenizer = pickle.load(f)

# Load the image features
print("Loading image features...")
with open(FEATURES_FILE, 'rb') as f:
    image_features = pickle.load(f)

print(f"Loaded {len(image_features)} image features.")

# Define Global Constants
vocab_size = len(tokenizer.word_index) + 1
max_length = get_max_length(captions_map)

print(f'Vocabulary Size: {vocab_size}')
print(f'Max Caption Length: {max_length}')

# Define the model
print("Defining model...")
model = define_model()

# Training Parameters
epochs = 20
batch_size = 64
steps = len(captions_map) // batch_size

# 1. Define the output signature for the generator
output_signature = (

    (tf.TensorSpec(shape=(None, 1000), dtype=tf.float32),  # Image features
     tf.TensorSpec(shape=(None, max_length), dtype=tf.int32)),  # Text sequence

    tf.TensorSpec(shape=(None, vocab_size), dtype=tf.float32)  # Output word
)

# 2. Create the tf.data.Dataset
train_dataset = tf.data.Dataset.from_generator(
    lambda: data_generator(batch_size),  # Use a lambda to call the generator
    output_signature=output_signature
).prefetch(buffer_size=tf.data.AUTOTUNE) # Add prefetch for performance

# 3. Set up a "checkpoint" to save the best model weights
checkpoint = ModelCheckpoint(MODEL_WEIGHTS_FILE,
                             monitor='loss',
                             verbose=1,
                             save_best_only=True,
                             mode='min')

# 7. Start Training
print("Starting training...")
model.fit(train_dataset,  # Pass the new dataset object
          epochs=epochs,
          steps_per_epoch=steps,
          verbose=1,
          callbacks=[checkpoint])

print("\n--- Training Complete ---")
print(f"Model weights saved to {MODEL_WEIGHTS_FILE}")