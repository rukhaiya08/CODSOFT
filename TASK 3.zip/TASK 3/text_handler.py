import string  # Used for text manipulation, specifically to remove punctuation.
from tensorflow.keras.preprocessing.text import Tokenizer  # The main Keras utility to turn text into numbers.
import pickle  # Used to save our trained tokenizer object to a file.


def load_captions(filename):
    """
    Loads the Kaggle 'captions.txt' file.
    This file is comma-separated and has a header.
    """
    with open(filename, 'r') as file:
        doc = file.read()

    captions_map = {}

    # Split by newline and skip the first line (the header)
    for line in doc.split('\n')[1:]:

        # Split only on the FIRST comma
        # This prevents errors if a caption itself contains a comma
        parts = line.split(',', 1)
        if len(parts) < 2:
            continue  # Skip any blank or malformed lines

        image_id, caption = parts[0], parts[1]

        # If this image_id hasn't been seen before, create a new empty list for it
        if image_id not in captions_map:
            captions_map[image_id] = []

        # Add the caption to this image's list of captions
        captions_map[image_id].append(caption)

    return captions_map


def clean_captions(captions_map):
    # Create a translation table that will be used to remove all punctuation
    # string.punctuation contains all punctuation characters
    table = str.maketrans('', '', string.punctuation)

    # Loop through each image and its list of captions in the dictionary
    for image_id, caption_list in captions_map.items():
        cleaned_list = []  # A new list to hold the cleaned captions for this image
        for caption in caption_list:
            # 1. Tokenize: Split the caption into individual words
            caption = caption.split()
            # 2. Convert all words to lowercase
            caption = [word.lower() for word in caption]
            # 3. Remove punctuation from each word
            caption = [word.translate(table) for word in caption]
            # 4. Remove short words (like 'a' or 's')
            caption = [word for word in caption if len(word) > 1]
            # 5. Remove words that are not alphabetic (e.g., '123', 'car1')
            caption = [word for word in caption if word.isalpha()]
            # 6. Rejoin words and add <start>/<end> tokens
            cleaned_caption = '<start> ' + ' '.join(caption) + ' <end>'
            cleaned_list.append(cleaned_caption)

        # Overwrite the original (raw) caption list with the new cleaned list
        captions_map[image_id] = cleaned_list


# --- 4. Define Helper Functions for Tokenizer ---

def create_all_captions_list(captions_map):
    all_captions = []
    # Loop through all keys (image_ids) in the dictionary
    for key in captions_map:
        # Add all captions for that image to the master list
        all_captions.extend(captions_map[key])
    return all_captions


def create_tokenizer(captions_list):
    # Initialize the Tokenizer.
    # oov_token='<unk>' will map any "out-of-vocabulary" (unknown) word
    # to a special '<unk>' token (index 1) instead of just ignoring it.
    tokenizer = Tokenizer(oov_token='<unk>')

    # 'fit_on_texts' reads all captions and builds the internal
    # word_index dictionary (e.g., {'dog': 5, 'cat': 6, ...})
    tokenizer.fit_on_texts(captions_list)
    return tokenizer



# Specify the name of your captions file
caption_file = 'captions.txt'

# 1. Load the raw captions into a dictionary
print("Loading captions...")
captions_map = load_captions(caption_file)

# 2. Clean all the captions in the dictionary
print("Cleaning captions...")
clean_captions(captions_map)

# 3. Create one giant list of all 40,000+ cleaned captions
all_captions_list = create_all_captions_list(captions_map)

# 4. Create and fit the tokenizer on this list
print("Fitting tokenizer...")
tokenizer = create_tokenizer(all_captions_list)

# 5. (Optional) Check your vocabulary size
# We add +1 because the word_index is 1-based, but we'll use 0 for padding.
vocab_size = len(tokenizer.word_index) + 1
print(f'Vocabulary Size: {vocab_size}')

# 6. (Optional) Check the word mapping for a few key words
# This confirms the tokenizer is set up correctly.
print('Word for index 1:', tokenizer.index_word[1])  # Should be '<unk>'
print('Word for index 2:', tokenizer.index_word[2])  # Should be '<start>'
print('Word for index 3:', tokenizer.index_word[3])  # Should be '<end>'
print('Index for "dog":', tokenizer.word_index['dog'])

# 7. Save the tokenizer for later use
print("Saving tokenizer to 'tokenizer.pkl'...")
with open('tokenizer.pkl', 'wb') as f:
    # 'pickle.dump' serializes the Python object and writes it to the file
    pickle.dump(tokenizer, f)

print("Text processing complete.")