import os
import pickle
import numpy as np
from tqdm import tqdm  # This adds a nice progress bar!
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import Model

# Loads the VGG16 model
def load_vgg16_model():
    # Load the model
    model = VGG16()
    # Remove the last layer (the classification layer)
    model.layers.pop()
    # Create a new model that outputs the second-to-last layer
    model = Model(inputs=model.inputs, outputs=model.layers[-1].output)
    print(model.summary())
    return model

# Loads an image and extracts its features using the VGG16 model
def extract_features(filename, model):
    try:
        # Load the image, resizing it to the 224x224 pixels VGG16 expects
        image = load_img(filename, target_size=(224, 224))

        # Convert the image pixels to a numpy array
        image = img_to_array(image)

        # Reshape the data for the model (it expects a batch)
        image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))

        # Pre-process the image for the VGG model (e.g., center pixels, etc.)
        image = preprocess_input(image)

        # Get the features
        feature = model.predict(image, verbose=0)
        return feature
    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return None


# (This folder was created by the !unzip command)
image_directory = 'Flicker8k_Dataset'

# 2. Load the VGG16 model
model = load_vgg16_model()

# 3. Create a dictionary to hold all the features
features = {}

print(f"Extracting features from images in: {image_directory}")

# 4. Loop through all images in the directory
# tqdm wraps the loop to show a progress bar
for filename in tqdm(os.listdir(image_directory)):
    # Full path to the image
    image_path = os.path.join(image_directory, filename)

    # Extract features
    feature = extract_features(image_path, model)

    if feature is not None:
        # Get the image ID (the filename itself, without .jpg)
        image_id = filename.split('.')[0]
        # Store the feature
        features[image_id] = feature

print("\nFeature extraction complete.")

# 5. Save the features dictionary to a pickle file
print("Saving features to 'features.pkl'...")
with open('features.pkl', 'wb') as f:
    pickle.dump(features, f)

print("Done. You now have features.pkl")