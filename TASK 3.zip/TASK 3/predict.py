import os
import pickle
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.layers import Input, Dense, LSTM, Embedding, Dropout, add

# File paths
TOKENIZER_FILE = 'tokenizer.pkl'
MODEL_WEIGHTS_FILE = 'model_weights.h5'
MAX_LENGTH = 34  # WE got this from our training output (Max Caption Length: 34)

# Load the Tokenizer
print("Loading tokenizer...")
with open(TOKENIZER_FILE, 'rb') as f:
    tokenizer = pickle.load(f)
vocab_size = len(tokenizer.word_index) + 1


# Define the Model Architecture (must be identical to training)
def define_model(vocab_size, max_length):
    inputs1 = Input(shape=(1000,))
    fe1 = Dropout(0.5)(inputs1)
    fe2 = Dense(256, activation='relu')(fe1)

    # Text sequence input
    inputs2 = Input(shape=(max_length,))
    se1 = Embedding(vocab_size, 256, mask_zero=True)(inputs2)
    se2 = Dropout(0.5)(se1)
    se3 = LSTM(256)(se2)

    # Merge
    decoder1 = add([fe2, se3])
    decoder2 = Dense(256, activation='relu')(decoder1)
    outputs = Dense(vocab_size, activation='softmax')(decoder2)

    model = Model(inputs=[inputs1, inputs2], outputs=outputs)
    model.compile(loss='categorical_crossentropy', optimizer='adam')
    return model


#Load the Trained Model Weights
print("Loading trained model weights...")
model = define_model(vocab_size, MAX_LENGTH)
model.load_weights(MODEL_WEIGHTS_FILE)

# Load the VGG16 Feature Extractor
print("Loading VGG16 feature extractor...")
# Load the VGG16 model
vgg_model = VGG16()
vgg_model = Model(inputs=vgg_model.inputs, outputs=vgg_model.layers[-1].output)
print("All models loaded.")


#Core Prediction Functions
def extract_features(filename, model):
    try:
        image = load_img(filename, target_size=(224, 224))
        image = img_to_array(image)
        image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))
        # Pre-process the image for the VGG model
        image = preprocess_input(image)
        feature = model.predict(image, verbose=0)
        return feature
    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return None

# Concvt an integer (index) back to its corresponding word.
def word_for_id(integer, tokenizer):
    for word, index in tokenizer.word_index.items():
        if index == integer:
            return word
    return None


# Generate a caption for an image
def generate_caption(model, tokenizer, image_features, max_length):
    in_text = 'start'

    # Loop for a maximum of max_length words
    for i in range(max_length):
        # Convert the current text sequence to integers
        sequence = tokenizer.texts_to_sequences([in_text])[0]
        # Pad the sequence to the fixed length
        sequence = pad_sequences([sequence], maxlen=max_length, padding='post')

        # Predict the next word
        # The model expects two inputs: image features and the text sequence
        yhat = model.predict([image_features, sequence], verbose=0)

        # Get the index of the word with the highest probability
        yhat = np.argmax(yhat)

        # Convert the index back to a word
        word = word_for_id(yhat, tokenizer)

        # If the word is unknown, stop
        if word is None:
            break

        # Append the new word to the sequence
        in_text += ' ' + word

        # If we predict the '<end>' token, stop
        if word == 'end':
            break

    final_caption = in_text.split()
    final_caption = [word for word in final_caption if word not in ('start', 'end')]
    final_caption = ' '.join(final_caption)
    return final_caption


# Example

test_image_path = 'Testing_Image/2.jpg'

# Extract the features from the test image
photo_features = extract_features(test_image_path, vgg_model)

# Generate the caption
caption = generate_caption(model, tokenizer, photo_features, MAX_LENGTH)

print("\n--- PREDICTION ---")
print(f"Image: {test_image_path}")
print(f"Caption: {caption}")


